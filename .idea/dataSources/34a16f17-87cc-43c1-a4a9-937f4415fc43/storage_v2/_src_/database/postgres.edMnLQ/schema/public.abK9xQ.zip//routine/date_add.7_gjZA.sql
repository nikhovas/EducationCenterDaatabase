create function date_add(date, integer) returns date
  language plpgsql
as
$$
declare
      day int := extract(day from $1);
      month int := extract(month from $1);
      year int := extract(year from $1);
    begin
      day := day + $2;
      if day > 31 then
        day := day - 31;
        month := month + 1;
      end if;
      if month > 12 then
        month := month - 12;
        year := year + 1;
      end if;
      return format('%s-%s-%s', year, month, day)::date;
    end;
$$;

alter function date_add(date, integer) owner to postgres;

