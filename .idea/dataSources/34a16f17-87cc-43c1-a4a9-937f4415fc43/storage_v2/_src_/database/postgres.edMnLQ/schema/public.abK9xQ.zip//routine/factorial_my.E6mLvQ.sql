create function factorial_my(integer) returns integer
  language plpgsql
as
$$
declare
      l integer := 1;
    begin
      for i in 1..$1
      loop
        l := l * i;
      end loop;
      return l;
    end;
$$;

alter function factorial_my(integer) owner to postgres;

