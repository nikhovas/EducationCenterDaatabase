create view v_teacher_org_name_2 as
SELECT ((teacher.last_name || ' '::text) || teacher.first_name) AS "Фамилия Имя",
       teacher.birth_date                                       AS "Дата рождения",
       organization.name_org                                    AS "Название организации"
FROM (teacher
       LEFT JOIN organization ON ((teacher.id_org = organization.id_org)));

alter table v_teacher_org_name_2
  owner to postgres;

