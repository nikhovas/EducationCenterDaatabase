create view v_teacher_org as
SELECT teacher.id_teach,
       teacher.last_name,
       teacher.first_name,
       teacher.birth_date,
       teacher.salary_amt,
       teacher.id_org
FROM teacher
WHERE (teacher.id_org IS NOT NULL);

alter table v_teacher_org
  owner to postgres;

