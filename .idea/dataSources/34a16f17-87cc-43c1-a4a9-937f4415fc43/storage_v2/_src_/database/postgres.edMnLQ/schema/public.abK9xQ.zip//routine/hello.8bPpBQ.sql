create function hello() returns character varying
  language plpgsql
as
$$
  --     declare
--       i integer := 0;
    begin
      return 'hello world';
    end;
$$;

alter function hello() owner to postgres;

