create function inverse_my(character varying) returns character varying
  language plpgsql
as
$$
declare
      l integer := 0;
      result varchar(100) = '';
    begin
      l := length($1);
      for i in 1..l
      loop
        result := result || substring($1, i, 1);
      end loop;
      return reverse($1);
    end;
$$;

alter function inverse_my(varchar) owner to postgres;

