create view v_teacher_org_name as
SELECT teacher.id_teach,
       teacher.last_name,
       teacher.first_name,
       teacher.birth_date,
       organization.name_org
FROM (teacher
       FULL JOIN organization ON ((teacher.id_org = organization.id_org)));

alter table v_teacher_org_name
  owner to postgres;

