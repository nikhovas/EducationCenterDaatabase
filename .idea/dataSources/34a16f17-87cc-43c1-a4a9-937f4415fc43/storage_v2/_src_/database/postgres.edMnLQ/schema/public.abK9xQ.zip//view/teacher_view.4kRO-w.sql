create view teacher_view as
SELECT teacher.id_teach,
       teacher.last_name,
       teacher.first_name,
       teacher.birth_date,
       teacher.salary_amt,
       teacher.id_org
FROM teacher;

alter table teacher_view
  owner to postgres;

