create function inverse(character varying) returns character varying
  language plpgsql
as
$$
  --     declare
--       i integer := 0;
    begin
      return reverse($1);
    end;
$$;

alter function inverse(varchar) owner to postgres;

