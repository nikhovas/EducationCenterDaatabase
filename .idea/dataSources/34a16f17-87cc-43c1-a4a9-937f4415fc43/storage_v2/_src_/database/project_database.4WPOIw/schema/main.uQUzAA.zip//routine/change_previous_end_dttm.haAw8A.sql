create function change_previous_end_dttm() returns trigger
  language plpgsql
as
$$
BEGIN
    UPDATE PERSON_DOCUMENT
      SET valid_to_dttm = NEW.valid_from_dttm
      WHERE person_id = NEW.person_id
      AND valid_to_dttm = '9999-12-31'
      AND document_no <> NEW.document_no
      AND document_series <> NEW.document_series;
    RETURN NEW;
  END;
$$;

alter function change_previous_end_dttm() owner to postgres;

