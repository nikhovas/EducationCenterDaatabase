create view incrementing_profit as
  WITH payment_dates AS (
    SELECT DISTINCT contract_payment.payment_dttm
    FROM main.contract_payment
    ORDER BY contract_payment.payment_dttm
  ),
       teacher_ids AS (
         SELECT teacher_person.person_id
         FROM main.teacher_person
       ),
       teacher_payments_by_date AS (
         SELECT teacher_person.person_id,
                contract_payment.payment_dttm,
                contract_payment.payment_amt
         FROM (((main.teacher_person
           LEFT JOIN main.course ON ((teacher_person.person_id = course.teacher_person_id)))
           LEFT JOIN main.contract ON ((course.course_id = contract.course_id)))
                LEFT JOIN main.contract_payment ON ((contract.contract_id = contract_payment.contract_id)))
       )
  SELECT teacher_payments_by_date.person_id,
         teacher_payments_by_date.payment_dttm,
         COALESCE(sum(teacher_payments_by_date.payment_amt)
                      OVER (PARTITION BY teacher_payments_by_date.person_id ORDER BY teacher_payments_by_date.payment_dttm),
                  (0)::bigint) AS increase_sum
  FROM teacher_payments_by_date
  ORDER BY teacher_payments_by_date.person_id, teacher_payments_by_date.payment_dttm;

alter table incrementing_profit
  owner to postgres;

