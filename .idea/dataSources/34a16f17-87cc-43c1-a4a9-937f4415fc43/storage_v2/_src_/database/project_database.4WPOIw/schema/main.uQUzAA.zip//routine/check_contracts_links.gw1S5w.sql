create function check_contracts_links() returns trigger
  language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (
      SELECT 1
      FROM STUDENT_PERSON
      WHERE person_id = NEW.student_person_id
    ) THEN
      RAISE EXCEPTION 'no student with such student id';
    ELSEIF NOT EXISTS (
      SELECT 1
      FROM PERSON
      WHERE person_id = NEW.payer_person_id
    ) THEN
      RAISE EXCEPTION 'no person with such payer id';
    ELSEIF NOT EXISTS (
      SELECT 1
      FROM COURSE
      WHERE course_id = NEW.course_id
    ) THEN
      RAISE EXCEPTION 'no course with such course id';
    END IF;

    RETURN NULL;
  END;
$$;

alter function check_contracts_links() owner to postgres;

