create view teacher_person_view as
SELECT t1.birth_dt,
       (("substring"((t1.inn_no)::text, 1, 3) || 'xxxxxxxxxx'::text) ||
        "substring"((t1.inn_no)::text, (length((t1.inn_no)::text) - 2), length((t1.inn_no)::text))) AS inn_no,
       t1.email_txt,
       t1.phone_no,
       t2.person_name_nm,
       t3.working_start_dt,
       t3.salary_amt,
       ('xxxx'::text || "substring"((t3.employment_record_no)::text, (length((t3.employment_record_no)::text) - 4),
                                    length((t3.employment_record_no)::text)))                       AS employment_record_no
FROM (((SELECT person.person_id,
               person.birth_dt,
               (person.inn_no)::character varying(15) AS inn_no,
               person.email_txt,
               person.phone_no
        FROM main.person) t1
  JOIN main.person_document t2 ON ((t1.person_id = t2.person_id)))
       JOIN (SELECT teacher_person.person_id,
                    teacher_person.working_start_dt,
                    teacher_person.salary_amt,
                    (teacher_person.employment_record_no)::character varying(15) AS employment_record_no
             FROM main.teacher_person) t3 ON ((t1.person_id = t3.person_id)))
WHERE (t2.valid_to_dttm = '9999-12-31 00:00:00'::timestamp without time zone);

alter table teacher_person_view
  owner to postgres;

