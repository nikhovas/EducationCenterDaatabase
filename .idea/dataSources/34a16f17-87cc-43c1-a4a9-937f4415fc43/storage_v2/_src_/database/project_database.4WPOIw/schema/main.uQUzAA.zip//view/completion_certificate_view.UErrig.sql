create view completion_certificate_view as
SELECT t2.sphere_txt,
       t2.name_txt,
       t3.person_name_nm,
       t1.classes_start_dt,
       t1.classes_end_dt
FROM ((main.completion_certificate t1
  JOIN main.course t2 ON ((t1.course_id = t2.course_id)))
       JOIN main.person_document t3 ON ((t1.student_person_id = t3.person_id)))
WHERE (t3.valid_to_dttm = '9999-12-31 00:00:00'::timestamp without time zone);

alter table completion_certificate_view
  owner to postgres;

