create view course_view as
SELECT t1.sphere_txt,
       t1.name_txt,
       t1.course_start_dt,
       t1.course_end_dt,
       t1.month_price_amt,
       t2.person_name_nm AS teacher
FROM (main.course t1
       JOIN main.person_document t2 ON ((t1.teacher_person_id = t2.person_id)));

alter table course_view
  owner to postgres;

