create view teacher_top as
SELECT rank() OVER (ORDER BY (count(contract.*)) DESC) AS rank,
       teacher_person.person_id,
       person_document.person_name_nm,
       count(contract.*)                               AS count
FROM (((main.teacher_person
  JOIN main.course ON ((teacher_person.person_id = course.teacher_person_id)))
  JOIN main.contract ON ((contract.course_id = course.course_id)))
       JOIN main.person_document ON ((teacher_person.person_id = person_document.person_id)))
WHERE (contract.termination_dttm IS NULL)
GROUP BY teacher_person.person_id, person_document.person_name_nm;

alter table teacher_top
  owner to postgres;

