create view contract_payment_view as
SELECT t3.sphere_txt,
       t3.name_txt,
       t4.person_name_nm,
       t1.payment_dttm,
       t1.payment_amt,
       t1.classes_year_no,
       CASE t1.classes_month_no
         WHEN 1 THEN 'ЯНВ'::text
         WHEN 2 THEN 'ФЕВ'::text
         WHEN 3 THEN 'МАР'::text
         WHEN 4 THEN 'АПР'::text
         WHEN 5 THEN 'МАЙ'::text
         WHEN 6 THEN 'ИЮН'::text
         WHEN 7 THEN 'ИЮЛ'::text
         WHEN 8 THEN 'АВГ'::text
         WHEN 9 THEN 'СЕН'::text
         WHEN 10 THEN 'ОКТ'::text
         WHEN 11 THEN 'НОЯ'::text
         WHEN 12 THEN 'ДЕК'::text
         ELSE 'ОШИ'::text
         END AS month
FROM (((main.contract_payment t1
  JOIN main.contract t2 ON ((t1.contract_id = t2.contract_id)))
  JOIN main.course t3 ON ((t2.course_id = t3.course_id)))
       JOIN main.person_document t4 ON ((t2.student_person_id = t4.person_id)))
WHERE (t4.valid_to_dttm = '9999-12-31 00:00:00'::timestamp without time zone);

alter table contract_payment_view
  owner to postgres;

