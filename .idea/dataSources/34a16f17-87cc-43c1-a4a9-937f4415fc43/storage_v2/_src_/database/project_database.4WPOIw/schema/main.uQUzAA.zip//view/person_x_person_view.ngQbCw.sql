create view person_x_person_view as
SELECT t2.person_name_nm,
       t3.person_name_nm AS x_person_name_nm,
       t1.connection_type_txt
FROM ((main.person_x_person t1
  JOIN main.person_document t2 ON ((t1.person_id = t2.person_id)))
       JOIN main.person_document t3 ON ((t1.x_person_id = t3.person_id)))
WHERE ((t2.valid_to_dttm = '9999-12-31 00:00:00'::timestamp without time zone) AND
       (t3.valid_to_dttm = '9999-12-31 00:00:00'::timestamp without time zone));

alter table person_x_person_view
  owner to postgres;

