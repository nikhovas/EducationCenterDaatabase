create view person_home_address_view as
SELECT t2.person_name_nm,
       t1.address_txt
FROM (main.person_home_address t1
       JOIN main.person_document t2 ON ((t1.person_id = t2.person_id)))
WHERE (t1.valid_to_dttm = '9999-12-31 00:00:00'::timestamp without time zone);

alter table person_home_address_view
  owner to postgres;

