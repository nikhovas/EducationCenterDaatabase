create view course_class_view as
SELECT t1.week_day_txt,
       t1.start_tm,
       t1.end_tm,
       t2.sphere_txt,
       t2.name_txt
FROM (main.course_class t1
       JOIN main.course t2 ON ((t1.course_id = t2.course_id)));

alter table course_class_view
  owner to postgres;

