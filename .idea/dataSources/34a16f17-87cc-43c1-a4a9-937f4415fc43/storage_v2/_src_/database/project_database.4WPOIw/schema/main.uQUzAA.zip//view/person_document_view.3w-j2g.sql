create view person_document_view as
SELECT person_document.document_series,
       person_document.document_no,
       person_document.document_type_txt,
       person_document.person_name_nm,
       person_document.authority_no
FROM main.person_document
WHERE (person_document.valid_to_dttm = '9999-12-31 00:00:00'::timestamp without time zone);

alter table person_document_view
  owner to postgres;

