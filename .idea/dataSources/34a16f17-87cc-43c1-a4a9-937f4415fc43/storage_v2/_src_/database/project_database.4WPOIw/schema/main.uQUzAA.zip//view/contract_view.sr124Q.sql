create view contract_view as
  SELECT t4.sphere_txt,
         t4.name_txt,
         t2.person_name_nm AS student_person,
         t3.person_name_nm AS payer_person,
         t1.contract_dttm,
         t1.termination_dttm
  FROM (((main.contract t1
    JOIN main.person_document t2 ON ((t1.student_person_id = t2.person_id)))
    JOIN main.course t4 ON ((t1.course_id = t4.course_id)))
         LEFT JOIN main.person_document t3 ON ((t1.payer_person_id = t3.person_id)))
  WHERE ((t2.valid_to_dttm = '9999-12-31 00:00:00'::timestamp without time zone) AND
         (t3.valid_to_dttm = '9999-12-31 00:00:00'::timestamp without time zone))
  UNION
  SELECT t4.sphere_txt,
         t4.name_txt,
         t2.person_name_nm       AS student_person,
         NULL::character varying AS payer_person,
         t1.contract_dttm,
         t1.termination_dttm
  FROM (((SELECT contract.contract_id,
                 contract.contract_dttm,
                 contract.student_person_id,
                 contract.course_id,
                 contract.termination_dttm
          FROM main.contract
          WHERE (contract.payer_person_id IS NULL)) t1
    JOIN main.person_document t2 ON ((t1.student_person_id = t2.person_id)))
         JOIN main.course t4 ON ((t1.course_id = t4.course_id)))
  WHERE (t2.valid_to_dttm = '9999-12-31 00:00:00'::timestamp without time zone);

alter table contract_view
  owner to postgres;

