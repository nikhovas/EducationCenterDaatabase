create function add_client(_person_name_mn character varying, _address_txt character varying, _birth_dt date, _inn_no character varying, _email_txt character varying, _phone_no character varying, _document_series character varying, _document_no integer, _document_type_txt character varying, _document_authority_no character varying) returns integer
  language plpgsql
as
$$
DECLARE
  new_person_id INT;
BEGIN
  IF EXISTS(
    SELECT 1
    FROM PERSON_DOCUMENT pd
    WHERE pd.document_series = _document_series
      AND pd.document_no = _document_no
      AND pd.document_type_txt = _document_type_txt
  ) THEN RAISE 'cannot create user with document which is already in database';
  ELSEIF EXISTS (
    SELECT 1
    FROM PERSON p
    WHERE p.inn_no = _inn_no
  ) THEN RAISE 'cannot create user with inn which is already in database';
  END IF;

  INSERT INTO PERSON(BIRTH_DT, INN_NO, EMAIL_TXT, PHONE_NO)
  VALUES (_birth_dt, _inn_no, _email_txt, _phone_no) RETURNING person_id INTO new_person_id;

  INSERT INTO PERSON_DOCUMENT(document_no, document_series, document_type_txt, person_id, person_name_nm, authority_no, valid_from_dttm)
  VALUES (_document_no, _document_series, _document_type_txt, new_person_id, _person_name_mn, _document_authority_no, now());

  INSERT INTO PERSON_HOME_ADDRESS(person_id, address_txt, valid_from_dttm)
  VALUES (new_person_id, _address_txt, now());

  RETURN new_person_id;
END;

$$;

alter function add_client(varchar, varchar, date, varchar, varchar, varchar, varchar, integer, varchar, varchar) owner to postgres;

